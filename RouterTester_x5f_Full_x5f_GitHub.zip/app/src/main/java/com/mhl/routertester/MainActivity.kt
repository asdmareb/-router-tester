
package com.mhl.routertester

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import android.widget.TextView
import kotlinx.coroutines.*
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private var isTesting = false
    private var success = 0
    private var failed = 0
    private var maxSustained = 0
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ipInput = findViewById<TextInputEditText>(R.id.ipInput)
        val portInput = findViewById<TextInputEditText>(R.id.portInput)
        val slider = findViewById<Slider>(R.id.concurrentSlider)
        val label = findViewById<TextView>(R.id.concurrentLabel)
        val successText = findViewById<TextView>(R.id.successText)
        val failedText = findViewById<TextView>(R.id.failedText)
        val maxText = findViewById<TextView>(R.id.maxText)
        val startBtn = findViewById<MaterialButton>(R.id.startBtn)
        val logView = findViewById<TextView>(R.id.logView)

        fun log(msg: String){
            val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            logView.text = "$time - $msg\n" + logView.text
        }

        slider.addOnChangeListener { _, value, _ ->
            label.text = "عدد الاتصالات: ${value.toInt()}"
        }

        suspend fun testOne(ip: String, port: Int): Boolean = withContext(Dispatchers.IO){
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(ip, port), 3000)
                socket.close()
                true
            } catch (e: Exception){ false }
        }

        startBtn.setOnClickListener {
            if (isTesting){
                isTesting = false
                startBtn.text = "بدء الاختبار"
                log("تم الإيقاف يدوياً")
                return@setOnClickListener
            }
            isTesting = true
            success = 0; failed = 0; maxSustained = 0
            successText.text = "0"; failedText.text = "0"; maxText.text = "0"
            logView.text = ""
            startBtn.text = "إيقاف الاختبار"
            val ip = ipInput.text.toString().ifBlank { "192.168.1.1" }
            val port = portInput.text.toString().toIntOrNull() ?: 80
            val total = slider.value.toInt()
            log("بدء الاختبار على $ip:$port - الهدف $total اتصال")

            scope.launch {
                var tested = 0
                var batch = 10
                while (tested < total && isTesting){
                    val currentBatch = min(batch, total - tested)
                    val jobs = (0 until currentBatch).map {
                        async { testOne(ip, port) }
                    }
                    val results = jobs.awaitAll()
                    val fails = results.count { !it }
                    val succ = results.count { it }
                    success += succ
                    failed += fails
                    maxSustained = max(maxSustained, success)

                    withContext(Dispatchers.Main){
                        successText.text = success.toString()
                        failedText.text = failed.toString()
                        maxText.text = maxSustained.toString()
                    }

                    if (fails > currentBatch * 0.4){
                        log("⚠️ نقطة انهيار عند $tested اتصال - فشل ${(fails*100/currentBatch)}%")
                        break
                    }
                    tested += currentBatch
                    batch = min(batch + 5, 50)
                    if (tested % 50 == 0) log("تم اختبار $tested / $total")
                    delay(300)
                }
                log("انتهى - أقصى تحمل مستقر: $maxSustained اتصال")
                isTesting = false
                startBtn.text = "بدء الاختبار"
            }
        }
    }
}
